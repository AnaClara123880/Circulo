function setup() {
  createCanvas(400, 400);
}

function draw() {
  background("white");
  fill("blue");
  textSize(64);
  textAlign(CENTER,CENTER)
  
  let maximo = width
}