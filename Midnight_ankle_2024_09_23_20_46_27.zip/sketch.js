let cor;
let posicaohorizontal;//x
let posicaovertical;//y

function setup() {
createCanvas(400,400);
background("white");
Cor=color(random(0,255), random(0,255),random(0,255));
Posicaohorizontal=200
Posicaovertical=200
}

function draw() {
fill(cor)
circle(PosicaoHorizontal,PosicaoVertical, 50);
if(mouseX<PosicaoHorizontal) {
   PosicaoHorizontal=PosicaoHorizontal-1
  
  
  
  
  if(mouseX<PosicaoHorizontal) {
    PosicaoHorizontal=PosicaoHorizontal-1
  }
  if(mouseX>PosicaoHorizontal) {
    PosicaoHorizontal=PosicaoHorizonta+1
    }
}